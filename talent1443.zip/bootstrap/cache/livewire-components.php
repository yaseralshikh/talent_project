<?php return array (
  'schools' => 'App\\Http\\Livewire\\Schools',
  'show-schools' => 'App\\Http\\Livewire\\ShowSchools',
  'students' => 'App\\Http\\Livewire\\Students',
);