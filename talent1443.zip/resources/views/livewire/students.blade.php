<div>
    <div class="container px-4 mx-auto sm:px-8">
        <div class="py-8">

            <div class="relative">
                <div class="absolute bottom-0 left-0">
                    <a wire:click.prevent="export" role="button" href="#" class="p-2 pl-2 pr-2 text-green-500 text-green-700 bg-transparent border-2 border-green-500 rounded-lg text-1xl text-md hover:bg-green-500 hover:text-gray-100 focus:border-2 focus:border-green-300"><i class="fas fa-file-excel"></i> Excel</a>
                </div>
            </div>

            <div class="flex flex-col my-2 sm:flex-row">
                <div class="flex flex-row mb-1 sm:mb-0">
                    <div class="relative">
                        <select wire:change="changeStatus($event.target.value)" class="block w-full h-full px-4 py-2 pr-8 leading-tight text-gray-700 bg-white border border-gray-400 rounded-l appearance-none focus:outline-none focus:bg-white focus:border-gray-500">
                            <option value='' >@lang('site.status')</option>
                            <option value='1'>@lang('site.updated')</option>
                            <option value='0'>@lang('site.unupdated')</option>
                        </select>
                    </div>
                </div>
                <div class="relative block">
                    <span class="absolute inset-y-0 left-0 flex items-center h-full pl-2">
                        <svg viewBox="0 0 24 24" class="w-4 h-4 text-gray-500 fill-current">
                            <path
                                d="M10 4a6 6 0 100 12 6 6 0 000-12zm-8 6a8 8 0 1114.32 4.906l5.387 5.387a1 1 0 01-1.414 1.414l-5.387-5.387A8 8 0 012 10z">
                            </path>
                        </svg>
                    </span>
                    <input wire:model="search" type="text" wire:model="search" type="text" placeholder="{{ __('site.search') }}" class="block w-full py-2 pl-8 pr-6 text-sm text-gray-700 placeholder-gray-400 bg-white border border-b border-gray-400 rounded-l rounded-r appearance-none sm:rounded-l-none focus:bg-white focus:placeholder-gray-600 focus:text-gray-700 focus:outline-none" />
                </div>
            </div>

            @if(count($students) > 0)

                <div class="px-4 py-4 -mx-4 overflow-x-auto sm:-mx-8 sm:px-8">
                    <div class="inline-block min-w-full overflow-hidden rounded-lg shadow">
                        <table class="min-w-full leading-normal">
                            <thead>
                                <tr>
                                    <th class="px-5 py-3 text-xs font-semibold tracking-wider text-left text-gray-600 uppercase bg-gray-100 border-b-2 border-gray-200">#</th>
                                    <th class="px-5 py-3 text-xs font-semibold tracking-wider text-left text-gray-600 uppercase bg-gray-100 border-b-2 border-gray-200">
                                        <a wire:click.prevent="sortBy('name')" role="button" href="#"> @lang('site.name') @include('includes._sort-icon', ['field' => 'name'])</a>
                                    </th>
                                    <th class="px-5 py-3 text-xs font-semibold tracking-wider text-left text-gray-600 uppercase bg-gray-100 border-b-2 border-gray-200">
                                        <a wire:click.prevent="sortBy('school_id')" role="button" href="#"> @lang('site.school') @include('includes._sort-icon', ['field' => 'school_id'])</a>
                                    </th>
                                    <th class="px-5 py-3 text-xs font-semibold tracking-wider text-left text-gray-600 uppercase bg-gray-100 border-b-2 border-gray-200">
                                        <a wire:click.prevent="sortBy('class')" role="button" href="#"> @lang('site.class') @include('includes._sort-icon', ['field' => 'class'])</a>
                                    </th>
                                    <th class="px-5 py-3 text-xs font-semibold tracking-wider text-left text-gray-600 uppercase bg-gray-100 border-b-2 border-gray-200">
                                        <a wire:click.prevent="sortBy('stage')" role="button" href="#"> @lang('site.stage') @include('includes._sort-icon', ['field' => 'stage'])</a>
                                    </th>
                                    <th class="px-5 py-3 text-xs font-semibold tracking-wider text-left text-gray-600 uppercase bg-gray-100 border-b-2 border-gray-200">@lang('site.mobile')</th>
                                    <th class="px-5 py-3 text-xs font-semibold tracking-wider text-left text-gray-600 uppercase bg-gray-100 border-b-2 border-gray-200">
                                        <a wire:click.prevent="sortBy('status')" role="button" href="#"> @lang('site.status') @include('includes._sort-icon', ['field' => 'status'])</a>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($students as $index=> $student)
                                    <tr class="text-center">
                                        <td class="px-5 py-5 text-sm bg-white border-b border-gray-200">
                                            <p class="text-gray-900 whitespace-no-wrap">{{ $index + 1 }}</p>
                                        </td>
                                        <td class="px-5 py-5 text-sm bg-white border-b border-gray-200">
                                            <p class="text-gray-900 whitespace-no-wrap">{{ $student->name }}</p>
                                        </td>
                                        <td class="px-5 py-5 text-sm bg-white border-b border-gray-200">
                                            <p class="text-gray-900 whitespace-no-wrap">{{ $student->school->name }}</p>
                                        </td>
                                        <td class="px-5 py-5 text-sm bg-white border-b border-gray-200">
                                            <p class="text-gray-900 whitespace-no-wrap">{{ $student->class }}</p>
                                        </td>
                                        <td class="px-5 py-5 text-sm bg-white border-b border-gray-200">
                                            <p class="text-gray-900 whitespace-no-wrap">{{ $student->stage }}</p>
                                        </td>
                                        <td class="px-5 py-5 text-sm bg-white border-b border-gray-200">
                                            <p class="text-gray-900 whitespace-no-wrap">{{ $student->mobile }}</p>
                                        </td>
                                        <td class="px-5 py-5 text-sm bg-white border-b border-gray-200">
                                            @if ($student->status == 1)
                                                <span
                                                    class="relative inline-block px-3 py-1 font-semibold leading-tight text-green-900">
                                                    <span aria-hidden
                                                        class="absolute inset-0 bg-green-200 rounded-full opacity-50"></span>
                                                    <span class="relative">@lang('site.updated')</span>
                                                </span>
                                            @else
                                                <span
                                                    class="relative inline-block px-3 py-1 font-semibold leading-tight text-green-900">
                                                    <span aria-hidden
                                                        class="absolute inset-0 bg-red-200 rounded-full opacity-50"></span>
                                                    <span class="relative">@lang('site.unupdated')</span>
                                                </span>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        <div class="px-5 py-5 bg-white border-t xs:flex-row xs:justify-between">
                            <span class="text-xs text-gray-900 xs:text-sm">
                                {{ $students->links() }}
                            </span>
                        </div>
                    </div>
                </div>
            @endif
        </div>
    </div>
</div>
